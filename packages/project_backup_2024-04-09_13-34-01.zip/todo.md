- [ ] seperate the database and frontend

Database VM
clone the repo
cd into project/vm/database
run ./setup.sh <- installs requirements
cd authentication
run ./server.php


close connection in vm/database/authentication/server.php